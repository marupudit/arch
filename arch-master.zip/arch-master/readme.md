# Automation & Performance Project Generator

Auto generates an example/skeleton project from the specified list using [Yeoman](http://yeoman.io/)

# Prerequisites

[Node.js](https://nodejs.org/en/)
[npm](https://www.npmjs.com/)
[Git](https://git-scm.com/)

# Installation

Install yeoman
```
npm install -g yo
```

Install this project generator locally using git(Enter git credentials if required)
```
npm install -g git+https://gitlab.thetestpeople.com/automation-accelerators/arch.git
```

# Usage

Create your project folder and navigate to the folder using the terminal/command line
```
mkdir MyProject
cd MyProject
```

From your newly created project directory run the following in the terminal
```
yo ten10:projectType
```

Follow the on screen prompts and the project will be created in the current directory. See project readme.md for usage instructions

# Currently supported project types

* JavaScript:
    * ten10:[puppeteer](https://developers.google.com/web/tools/puppeteer/) - Generates a puppeteer project with example tests.
    * ten10:[testcafe](https://devexpress.github.io/testcafe/) - Generates a testcafe project with example tests
    * ten10:[cypress](https://docs.cypress.io/guides/overview/why-cypress.html#In-a-nutshell) - Generates a Cypress project with a test
    * ten10:[pact](https://docs.pact.io/) - Generates a consumer or provider to see PACT examples for each side of contract testing
* C#:    
    * ten10:[ocaramba](https://github.com/ObjectivityLtd/Ocaramba) - Generates an out of the box C# Webdriver framework with example tests
    * ten10:[flaui](https://github.com/Roemer/FlaUI) - Generates a FlaUI Windows application test framework with example tests  
* Java:
    * ten10:[frameworkium](https://frameworkium.github.io/) - Generates an out of the box Java Webdriver framework with example tests
    * ten10:[serenity](https://serenity-bdd.github.io/theserenitybook/latest/getting-started.html) - Generates an out of the box Java Webdriver framework with example tests
* Python:
    * ten10:[seleniumbase](https://seleniumbase.com/) - Generates a Python UI test framework with example tests   
