'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {
 
  async prompting() {
    this.answers = await this.prompt([{
      type    : 'input',
      name    : 'baseUrl',
      message : 'Enter the project base url',
      default: 'https://www.ten10.com'
    },
    {
      type    : 'input',
      name    : 'projectCode',
      message : 'Enter the project code',
      default: 'TEN1234'
    }
    ]);
  }

  writing() {
    this.fs.copy(
      this.templatePath('./'),
      this.destinationPath('./')
    );
    this.fs.copy(
      this.templatePath('./.npmignore'),
      this.destinationPath('./.gitignore')
    );
    this.fs.copyTpl(
      this.templatePath('config.js'),
      this.destinationPath('config.js'),
      { baseUrl: this.answers.baseUrl,
      projectCode: this.answers.projectCode } 
    );
  }

  install() {
    this.npmInstall();
  }
}