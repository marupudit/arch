const env = process.env.NODE_ENV
const _ = require('lodash');
var argv = require('minimist')(process.argv.slice(2));

// Specific Environment Variables
const dev = {
  "baseUrl": "<%= baseUrl %>"
};

const test = {
  "baseUrl": "<%= baseUrl %>"
}

// Default/ Shared config
const defaultConfig = {
  "influxHost": "grafana.ten10.com",
  "influxPort":8086,
  "influxDatabase":"datasource", 
  "influxTable": "puppeteer.<%= projectCode %>.timings" // Change TEN1234 to Project Code 
 };

 const config = {
   dev,
   test
 }

var finalConfig = _.merge(defaultConfig, config[env], argv);

module.exports = finalConfig;
 
