var BrowserManagement = require('../utils/browserManagement.js').BrowserManagement;
global.gBrowserManagement = new BrowserManagement();
var TheUser = require('../utils/TheUser.js')
var HomePage = require('../pages/ten10homepage.js').Ten10Homepage
var assert = require('assert');
var config = require('../config')


describe('Sample Test Suite', async function () {

  beforeEach(async function launchBrowser() {
    await gBrowserManagement.launchChrome();
    
    homepage = new HomePage();
    await homepage.open();

  });

  it('Navigate to Join Page', async function () {

    joinPage = await homepage.clickLink("Join")
    assert.equal(await joinPage.getTitle(), 'Join Ten10');
  });

  it('Navigate to Services', async function () {
    servicesPage = await homepage.clickLink("Services");
    assert.equal(await servicesPage.getTitle(), 'Join Ten10');
  });

  afterEach(async function closeBrowser() {
    if (this.currentTest.state == 'failed') {
      await gBrowserManagement.getScreenShot();
    }
    await gBrowserManagement.killchrome();
  });

})