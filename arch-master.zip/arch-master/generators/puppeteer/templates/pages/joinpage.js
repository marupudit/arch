class JoinPage {

    constructor() {
        this.page = gBrowserManagement.page;
        this.perfManagement = gBrowserManagement.perfManagement
    }

    async getTitle() {
        return this.page.title();
    }

}
module.exports = { JoinPage }