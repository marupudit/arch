var config = require('../config');
var JoinPage = require('./joinpage.js')

class Ten10Homepage {

    constructor() {
        this.page = gBrowserManagement.page;
        this.perfManagement = gBrowserManagement.perfManagement
    }

    async open() {
        await this.perfManagement.performanceWrapper("Open Homepage", [`this.page.goto(config.baseUrl);`]);
    }

    async clickLink(linkText) {

        /**
         * Using vanilla puppeteer -
         * await this.page.waitForXPath(`//a[text()="${linkText}"]`).then(x => x.click());
         * await this.page.waitForNavigation({ waitUntil: 'networkidle2' });
         * await this.perf.Management.getMetrics(`Click ${linkText}`);
         */

        // Using performance wrapper:
        await this.perfManagement.performanceWrapper(`Click ${linkText}`, [
            'this.page.waitForXPath(`//a[text()="${that}"]`).then(x => x.click())',
            "this.page.waitForNavigation({ waitUntil: 'networkidle2' })"], linkText);
            
        return new JoinPage.JoinPage();
    }

}
module.exports = { Ten10Homepage }