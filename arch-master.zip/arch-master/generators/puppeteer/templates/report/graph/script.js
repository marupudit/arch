var data = []
var ctx = document.getElementById("transactionMetrics");
var dataset = new Map()
var yLabels = []

data.forEach(element => {
    Object.keys(element).forEach(key => {
        yLabels.push(key)
        var el = element[key]
        Object.keys(el).forEach(metric => {
            var value = parseFloat(el[metric])
            if (dataset.has(metric)) {
                var map = dataset.get(metric)
                map.data.push(value)
            }
            else {
                dataset.set(metric, { data: [value], label: metric, fill: false, borderColor: getRandomColor() })
            }
        })
    })
})
var chart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: yLabels,
        datasets: Array.from(dataset.values())
    }
});

function getRandomColor() {
    var letters = '0123456789ABCDEF'.split('');
    var color = '#';
    for (var i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}