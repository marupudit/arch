class TheUser 
{

    constructor(page, useThinkTimes) 
    {
        this.page = page
        this.useThinkTimes = useThinkTimes
    }

    async thinkTime(milliSeconds)
    {
        if (this.useThinkTimes) 
        {
            await this.page.waitFor(milliSeconds);
        }
    }
}