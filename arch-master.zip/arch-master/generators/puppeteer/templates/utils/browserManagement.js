const perfManagement = require('./performanceMetricsManagement.js')
const puppeteer = require('puppeteer');
var fs = require('fs');

class BrowserManagement {

    constructor() {
        this.browser
        this.page
        this.perfManagement = perfManagement
    }

    async launchChrome() {
        var isHeadless = JSON.parse(config.headless || false);
        var proxyHost = config.proxyHost || null;
        var proxyPort = config.proxyPort || null;

        var additionalArgs = [];
        if (!isHeadless) {
            additionalArgs.push('--start-maximized');
        }
        if (proxyHost != null && proxyPort != null) {
            additionalArgs.push(`--proxy-server=${proxyHost}:${proxyPort}`)
        }

        this.browser = await puppeteer.launch({ headless: isHeadless, args: additionalArgs, ignoreHTTPSErrors: true });
        await this.createPage();
        await perfManagement.setupCDPPerformanceMetrics(this.page)
    }

    async killchrome() {
        await this.browser.close();
    }

    async createPage() {
        var pages = await this.browser.pages();
        this.page = pages[0];
        await this.page.setViewport({ width: 1920, height: 1080 });
    }

    async getScreenShot() {
        var time = new Date().getTime();
        var dir = './screenshots';

        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir);
        }
        await this.page.screenshot({ path: `${dir}/error-${time}.png`, fullPage: true });
    }

}

module.exports = { BrowserManagement }
