const Influx = require('influx');
config = require('../config')

const influx = new Influx.InfluxDB({
  host: config.influxHost,
  database: config.influxDatabase,
  port: config.influxPort,
});

function writeToInflux(transactionName, auditLabel, responseTime) {
  influx.writePoints([
    {
      measurement: config.influxTable,
      tags: { label: transactionName, metric: auditLabel, step: transactionName },
      fields: {
        value: responseTime,
      },
    },
  ]);
}

module.exports = { writeToInflux };