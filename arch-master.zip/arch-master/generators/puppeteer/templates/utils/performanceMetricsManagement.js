grafanaReporting = require('./grafanaReporting.js');
var config = require('../config');
const fs = require('fs');
var timer = require('marky');
var tableify = require('tableify');

/**
 * Creates client for recording performance metrics.
 * 
 * @param {page} page Puppeteer page object.
 * @return {<Promise<CDPSession>>} Promise containing the new client.
 * 
 * @example
 *      client = await setupCDPPerformanceMetrics(this.page)
 */
async function setupCDPPerformanceMetrics(page) {
    this.page = page;
    client = await page.target().createCDPSession();
    client.send('Performance.enable');

    return client;
}

/**
 * If config.captureMetrics is true, this function is called to record the metrics for a step.
 * 
 * @param {string} transactionName The name of the steps to record the metrics for.
 * @param {string=} traceMetrics The specific metrics to be recorded. (Optional).
 * 
 * @example
 *      await getMetrics("Nav to Homepage", "firstContentfulPaint");
 */
async function getMetrics(transactionName, traceMetrics) {

    var captureMetrics = config.captureMetrics || false;
    if (captureMetrics != false) {

        do {
            await this.page.waitFor(100);
            performanceMetrics = await client.send('Performance.getMetrics');
            extractedMetrics = await extractDataFromPerformanceMetrics(performanceMetrics);
            await this.page.waitFor(100);

        } while (extractedMetrics.FirstMeaningfulPaint == undefined);

        performanceTiming = JSON.parse(
            await this.page.evaluate(() => JSON.stringify(window.performance.timing))
        );
        initialMetrics = extractDataFromPerformanceTiming(performanceTiming);

        if (captureMetrics === 'local') {
            // Check for existing output
            var combinedMetrics
            try {
                combinedMetrics = JSON.parse(fs.readFileSync('./metrics.json'));
            } catch (error) {
                combinedMetrics = {};
            }

            if (combinedMetrics[transactionName] === undefined) {
                combinedMetrics[transactionName] = {};
            }

            for (const key in traceMetrics) {
                combinedMetrics[transactionName][key] = getAverage(combinedMetrics[transactionName], traceMetrics, key);
            }

            // Write recorded metrics to HTML table and add data to graphing script.
            fs.writeFileSync('./metrics.json', JSON.stringify(combinedMetrics));

            var header = '<head><link rel="stylesheet" type="text/css" href="style.css" /></head>';
            var link = '<div><a href="./graph/index.html">Graph</a></div>';
            var html = tableify([combinedMetrics]);
            fs.writeFileSync('./report/metrics.html', `${header}${html}${link}`);

            var existingText = fs.readFileSync('./report/graph/script.js');
            existingText = existingText.toString().replace(/var data.*?\]/g, `var data=[${JSON.stringify(combinedMetrics)}]`)
            fs.writeFileSync('./report/graph/script.js', existingText);
        } else {
            if (traceMetrics != undefined) {
                if (('firstContentfulPaint' in traceMetrics)) {
                    for (const key in initialMetrics) {
                        grafanaReporting.writeToInflux(transactionName, key, initialMetrics[key]);
                    }
                    for (const key in extractedMetrics) {
                        grafanaReporting.writeToInflux(transactionName, key, extractedMetrics[key]);
                    }
                }
            } else {
                for (const key in initialMetrics) {
                    grafanaReporting.writeToInflux(transactionName, key, initialMetrics[key]);
                }
                for (const key in extractedMetrics) {
                    grafanaReporting.writeToInflux(transactionName, key, extractedMetrics[key]);
                }
            }
            for (const key in traceMetrics) {
                if (traceMetrics[key] > 0) {
                    grafanaReporting.writeToInflux(transactionName, key, traceMetrics[key]);
                }
            }
        }
    }
}

function getAverage(combinedMetrics, subMetric, key) {
    var res;

    if (key in combinedMetrics) {
        var num = (subMetric[key] + parseFloat(combinedMetrics[key])) / 2;
        res = num;
    } else {
        res = subMetric[key];
    }

    if (typeof res === "number") {
        return parseFloat(res.toFixed(2));
    } else {
        return parseFloat(res);
    }
}

/**
 * Extract the timing for a specific step from recorded metrics.
 * 
 * @param {object} metrics The object containing the recorded metrics.
 * @param {string} name The name of the specific timing to return.
 * @return {number} The timing (in ms) recorded for the metric with the given name.
 * 
 * @example
 *      navigationStart = getTimeFromPerformanceMetrics(metrics, 'NavigationStart');
 * 
 */
const getTimeFromPerformanceMetrics = (metrics, name) =>
    metrics.metrics.find((x) => x.name === name).value * 1000;

/**
 * Adjust the recorded metrics to account for the start of the step.
 * 
 * @param {object} metrics The object containing the recorded metrics.
 * @return {object} containing the updated metrics.
 * 
 * @example 
 *      extractedMetrics = await extractDataFromPerformanceMetrics(performanceMetrics);
 */
const extractDataFromPerformanceMetrics = (metrics) => {
    const navigationStart = getTimeFromPerformanceMetrics(
        metrics,
        'NavigationStart'
    );
    const extractedData = {};

    for (let index = 0; index < metrics.metrics.length; index++) {
        if (metrics.metrics[index]['value'] * 1000 - navigationStart > 0) {
            extractedData[metrics.metrics[index]['name']] = Math.round(metrics.metrics[index]['value'] * 1000 - navigationStart);
        };
    };

    return extractedData;
};

/**
 * Adjusts the response timings to account for the time at the start of the step.
 * 
 * @param {object} timing The recorded response timings taken from the page.
 * @return {object} The recorded response times adjusted for the start time of the page load.
 * 
 * @example
 *      initialMetrics = extractDataFromPerformanceTiming(performanceTiming);
 */
const extractDataFromPerformanceTiming = (timing) => {
    const navigationStart = timing.navigationStart;
    const extractedData = {};
    for (const key in timing) {
        if (timing[key] - navigationStart > 0)
            extractedData[key] = timing[key] - navigationStart;
    }

    return extractedData;
};

/**
 * Parse the raw tracing data for the desired metrics.
 * 
 * @param {string} transactionName The name of the transaction step e.g. 'Nav to homepage'
 * @param {object} overallTransactionTime The recorded time for the transaction e.g. {"entryType": "measure","startTime": 1974112,"duration": 350,"name": "manTheTorpedos"}
 * @return {object} The extracted tracing metrics.
 * 
 * @example
 *      traceMetrics = await extractDataFromTracing(entry);
 */
async function extractDataFromTracing(transactionName, overallTransactionTime) {
    const fileName = `./${transactionName}-trace.json`;
    file = await fs.readFileSync(fileName);
    const tracing = await JSON.parse(file);
    const listOfMetrics = ['firstContentfulPaint', 'firstPaint', 'firstMeaningfulPaint', 'loadEventEnd', 'responseEnd'];
    traceMetrics = {};
    const navigationStart = await tracing.traceEvents.filter(x => x.name === 'navigationStart');

    listOfMetrics.forEach(metric => {
        const event = tracing.traceEvents.filter(x => x.name === metric);
        event.sort(function (a, b) { return b.tts - a.tts });
        try {
            traceMetrics[metric] = (event[0].ts - navigationStart[0].ts) / 1000;
        } catch (error) {
            traceMetrics[metric] = NaN;
        }
    });

    traceMetrics['overallTransactionTime'] = overallTransactionTime.duration;
    if (config.saveTrace == undefined || !config.saveTrace.includes(transactionName)) {
        await fs.unlinkSync(`./${transactionName}-trace.json`);
    }

    return traceMetrics;
}

/**
 * Records tracing data for steps which don't trigger a navigation.
 * 
 * @param {string} name The name to record the step as.
 * @param {string[]} functions Array of strings containing puppeteer steps to perform.
 * @param {object=} that Helper param for referencing other objects within the passed functions.
 * 
 * @example
 *      await performanceMetricsManagement.performanceWrapper("Select Stockist county", [
 *          "this.page.waitForXPath(`//a[contains(text(), '${that}')]`).then(x => x.click())", 
 *          "this.page.waitForNavigation({ waitUntil: 'networkidle0'})"], county);
 */
async function performanceWrapper(name, functions, that) {
    if (typeof functions === 'string') {
        functions = [functions];
    }

    try {
        await timer.mark(name);
        await this.page.tracing.start({ screenshots: true, path: `./${name}-trace.json` });
        for (let index = 0; index < functions.length; index++) {
            await eval(functions[index]).catch(err => { throw err });
        }
        await this.page.tracing.stop();
        var entry = await timer.stop(name);
        const traceMetrics = await extractDataFromTracing(name, entry);
        await this.getMetrics(name, traceMetrics);
    } catch (error) {
        try {
            await this.page.tracing.stop();
        } catch (error) {
        }

        throw (error);
    }

}

module.exports = { setupCDPPerformanceMetrics, getMetrics, extractDataFromTracing, performanceWrapper }
