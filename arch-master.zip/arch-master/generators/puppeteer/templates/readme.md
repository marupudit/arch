# Performance Puppeteer Template

Tests written using Google's Puppeteer framework to allow capturing of metrics such as 'first meaningful paint'. See [Puppeteer Docs](https://developers.google.com/web/tools/puppeteer/) for more info.

Uses [Mocha Test Framework](https://mochajs.org/)

## Prerequisites

[Node.js](https://nodejs.org/en/)
[npm](https://www.npmjs.com/)

## Installation

All dependencies will be installed by running

``` sh
npm install
```

## Project Structure

``` txt
project
|-- pages        <!--- Page Object Layer (Update to reflect your page objects --->
|   -- joinpage.js
|   -- ten10homepage.js
|-- test         <!--- Test Layer (Update to reflect your test scenarios)--->
|   -- exampletest.js
|-- utils        <!--- Browser management & Performance Metrics Capturing Code (Should not need to be updated) --->
|   -- browserManagement.js
|   -- grafanaReporting.js
|   -- performanceMetricsManagement.js
|-- config.js
|-- package.json
|-- readme.md
```

## Running tests

To run individual tests (use Jmeter to provide granular control over each journey)

``` sh
NODE_ENV=test ./node_modules/mocha/bin/mocha --fgrep="Guest Checkout" test/ --headless=false
```

## Configuration

Configuration is provided in the config.js file, use the default section for shared configuration & add to/create new environment variables.

Run time parameters can be passed by appending --KEY=VALUE to the end of the run command, these will be apended to the exisitng config and can be accessed using config.KEY throughout the project.

Environment is configured using: **NODE_ENV=test** (The value should match a config entry. )

## Capturing Performance Metrics

All that is required to capture performance metrics is calling getMetrics("Transaction Name") after a user action and it will be availbale to view in influx/Grafana.

A wrapper function has been provided for recording the metrics when the step in question doesn't trigger a full page load. This is used as follows:
performanceWrapper("Transaction Name", ["Steps to be run as normal"], object to be passed to steps);

Metrics are not captured by default (to avoid spamming Influx whilst creating/debugging scripts). To enable metric capturing add the following key/value: **--captureMetrics=true**

``` js
await this.page.goto(config.baseUrl);
await this.perfManagement.getMetrics("Open Homepage");
```

## Running from Jmeter

The script is setup to run 1 user & 1 iteration. To control users & iterations/runtime run from Jmeter.

An example Jmeter script to run the script is included in this project.
