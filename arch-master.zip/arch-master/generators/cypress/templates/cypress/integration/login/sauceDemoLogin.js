import { Given, When, Then } from "cypress-cucumber-preprocessor/steps";
import LoginPage from "../../pages/loginPage.js";
import NavigateTo from "../../pages/navigateTo.js";
const loginPage = new LoginPage();
const navigateTo = new NavigateTo();

//Step Definitions for the login feature
Given("I am on the homepage", () => {
  navigateTo.navigateToLogin();
});

When("I log in", () => {
  loginPage.fillLoginCredentials();
  loginPage.submit();
});

Then("I am taken to the {string} page", (inventory) => {
  cy.url().should('include', inventory);
  cy.log("Succesfully on products page");
});
