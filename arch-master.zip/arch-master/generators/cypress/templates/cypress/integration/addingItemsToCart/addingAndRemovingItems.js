import { Given, When, Then, And } from "cypress-cucumber-preprocessor/steps";
import ProductsPage from "../../pages/productsPage.js";
import LoginPage from "../../pages/loginPage.js";
import NavigateTo from "../../pages/navigateTo.js";
const productsPage = new ProductsPage();
const loginPage = new LoginPage();
const navigateTo = new NavigateTo();

//Step Definitions for adding and removing items from the cart
Given("I am logged in on the product page", () => {
  navigateTo.navigateToLogin();
  loginPage.fillLoginCredentials();
  loginPage.submit();
});

When("I add the backpack to the cart", () => {
  productsPage.addBackPackToCart();
});

And("I remove the backpack from the cart", () => {
  productsPage.removeBackpack();
});

Then("nothing is displayed next to cart icon", () => {
  productsPage.nothingInCart();
});

Then("a {string} is displayed next to cart icon", (number) => {
  productsPage.checkNumberNextToCart(number);
});
