import BasePage from "./basePage.js";
import LoginPage from "./loginPage.js";
const loginPage = new LoginPage();
const basePage = new BasePage();

export default class NavigateTo extends BasePage {

  navigateToLogin(){
    basePage.navigate("");
  }

  loginAndNavigate(path) {
    this.navigateToLogin();
    loginPage.fillLoginCredentials();
    loginPage.submit();
    basePage.navigate(path);
  }
}
