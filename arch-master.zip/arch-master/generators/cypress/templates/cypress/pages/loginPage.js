import BasePage from "./basePage.js";

export default class LoginPage extends BasePage {
  constructor() {
    super();
  }
//Elements on the page
  username = "#user-name";
  password = "#password";
  loginButton = "#login-button";

  fillLoginCredentials() {
    let field = cy.get(this.username);
    field.clear(); 
    field.type(Cypress.env('user')); //Gets the user from cypress.env.json

    field = cy.get(this.password);
    field.clear();
    field.type(Cypress.env('password'));
  }
  submit() {
    cy.get(this.loginButton).click();
  }
}
