export default class BasePage {
  baseURL = Cypress.env('baseURL');

  //Method for navigating around the base URL
  navigate(path) {
    cy.visit(this.baseURL + path)
  }

  getPageTitle() {
    return cy.title()
  }

  checkElementIsVisible(element){
    var style = window.getComputedStyle(element);
    return (style.display === 'none')
  }
}
