import BasePage from "./basePage.js";

export default class ProductsPage extends BasePage {
  constructor() {
    super();
  }
//Elements on the page
  addToCartBackpack = "#add-to-cart-sauce-labs-backpack";
  addToCartBikeLight = "#add-to-cart-sauce-labs-bike-light";
  addToCartBoltTshirt = "#add-to-cart-sauce-labs-bolt-t-shirt";
  addToCartFleeceJacket = "#add-to-cart-sauce-labs-fleece-jacket";
  addToCartOnesie = "#add-to-cart-sauce-labs-onesie";
  numberNextToCart = ".shopping_cart_badge";
  shoppingCartIcon = ".shopping_cart_link";
  deleteBackpack = "#remove-sauce-labs-backpack";

  //Methods for interacting with the page
  addBackPackToCart() {
    cy.get(this.addToCartBackpack).click();
  }

  addBikeLightToCart(){
    cy.get(this.addToCartBikeLight).click();
  }

  addBoltTshirtToCart(){
    cy.get(this.addToCartBoltTshirt).click();
  }

  addFleeceJacketToCart(){
    cy.get(this.addToCartFleeceJacket).click();
  }

  addOnesieToCart(){
    cy.get(this.addToCartOnesie).click();
  }


  checkNumberNextToCart(number) {
    cy.get(this.numberNextToCart).invoke('text').should('eq', number);
  }

  nothingInCart(){
   cy.get(this.numberNextToCart).should('not.exist');
  }


  clickShoppingCart(){
    cy.get(this.shoppingCartIcon).click();
  }

  removeBackpack(){
    cy.get(this.deleteBackpack).click();
  } 
}
