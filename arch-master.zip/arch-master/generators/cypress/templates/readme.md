# Cypress Page Object Model
A demo/skeleton Cypress project utilising Cucumber with Page Object Model.   
This demo can be run locally or as a container using the Dockerfile provided. Additionally, a basic example of CI with Github actions and Cypress dashboard is included.

## Prerequisites
Docker needs to be installed to be able to build and run the image.
Node v12+ to install and run locally.

## Installation
"npm i" in the project folder to be able to run locally.

## Scripts
### "npm run cypress:run"
Runs Cypress locally.
### "npm run cypress:build"
Builds the docker image and tags it as cypress_image.
### "npm run cypress:runDocker"
Runs the docker image.
### "npm run cypress:open"
Opens Cypress GUI on local.

## Configuration
Handled in the cypress.json file

## Dockerfile
An example Dockerfile is included.
For different versions of the base Cypress image, or different browser versions see https://github.com/cypress-io/cypress-docker-images

## Continuous Integration
This project contains an example of GH actions at .github\workflows\ci.yml , which also utilises Cypress' project dashboard feature.  
  
To utilise this yourself:  
  
First open Cypress GUI with "npm run cypress:open" and go to the 'Runs' tab, then open Cypress dashboard.  
  
From there create a project and add the project ID to your cypress.json file under "projectId".  
  
Copy the project KEY and set up a github repository for your project, then add your cypress project KEY as an environmental variable in github's secrets as 'CYPRESS_RECORD_KEY'.  
  
Every time you push a change to the repo GH actions will run your tests, save the test artifacts and record the results on your Cypress project dashboard. The ci.yml is set up to run the tests on multiple OSes.

## Plugins
This project uses the Cypress Cucumber Preprocessor plugin, documentation at https://github.com/TheBrainFamily/cypress-cucumber-preprocessor

## Environmental Variables
Environment variables can be added via the cypress.env.json file and accessed within the code with:

Cypress.env('keyValue')

## Example folder

Cypress comes, by default, with a set of .spec examples, which can be found in the integration folder. To be able to see these tests in cypress either modify or remove "testFiles" in cypress.json.
