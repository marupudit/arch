import os

config = {
    'dev': {
        'url': '<%= baseUrl %>'
    },
    'test': {
        'url': '<%= baseUrl %>'
    }
}

def pytest_addoption(parser):
    parser.addoption("--environment", action="store", default="dev")


def pytest_configure(config):
        os.environ["env"] = config.getoption('environment')
