class HomePage(object):
    def clickLink(seleniumbase, linkText):
        seleniumbase.click_xpath(f"//a[text()='{linkText}']")