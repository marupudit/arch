# Example Project using Python & Selenium Webdriver

A demo/skeleton project using Python's implementation of Selenium Webdriver. The framework is built using [SeleniumBase](https://github.com/seleniumbase/SeleniumBase) 

See project docs for more info on how to use. 

# Prerequisites
[Python](https://www.python.org/downloads/) - Make sure pip is installed with setuptools & wheel

# Installation

All project depdendencies will be installed by running
```
python setup.py install
```

# Project Structure
```
project
|-- pages        <!--- Page Object Layer (Update to reflect your page objects ---> 
|   -- homepage.py
|-- tests         <!--- Test Layer (Update to reflect your test scenarios)--->
|   -- exampletest.py
|-- conftest.py
|-- readme.md
|-- runTests.sh <!--- Script to execute tests --->
|-- setup.py  <!--- Dependency installation script --->
```

# Running tests

To run example tests:

```
./runTests.sh
```
# Configuration
Configuration is provided in the config.js file, use the default section for shared configuration & add to/create new environment variables. 

Run time parameters can be passed by appending --KEY=VALUE to the end of the run command, these will be apended to the exisitng config and can be accessed using config.KEY throughout the project.

Further runtime configuration can be viewed in the testcafe docs