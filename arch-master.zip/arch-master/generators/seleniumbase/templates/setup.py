from setuptools import setup

setup(
    name="<%= projectName %>",
    python_requires='>=3.7.0',
    install_requires=['seleniumbase']
)