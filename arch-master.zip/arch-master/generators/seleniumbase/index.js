'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {
 
  async prompting() {
    this.answers = await this.prompt([{
      type    : 'input',
      name    : 'baseUrl',
      message : 'Enter the project base url',
    },
    {
      type    : 'input',
      name    : 'projectName',
      message : 'Enter the project name',
    }
    ]);
  }

  writing() {
    this.fs.copy(
      this.templatePath('./'),
      this.destinationPath('./')
    );
    this.fs.copyTpl(
      this.templatePath('conftest.generated.py'),
      this.destinationPath('conftest.generated.py'),
      { baseUrl: this.answers.baseUrl}
    );
    this.fs.copyTpl(
      this.templatePath('setup.py'),
      this.destinationPath('setup.py'),
      { projectName: this.answers.projectName } 
    );
  }

  install() {
    this.spawnCommand("python", ['setup.py', 'install'])
  }
}