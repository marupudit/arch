'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {

  async prompting() {

    this.answers = await this.prompt([
      {
        type    : 'list',
        name    : 'testFormat',
        message : 'Select consumer or provider to see PACT examples for each side of contract testing',
        choices : ['consumer', 'provider']
      },
      {
      type    : 'input',
      name    : 'groupId',
      message : 'Enter the Maven GroupId',
    }
    ]);
  }

  writing() {
    var templatePath = `pact_${this.answers.testFormat}`
    var projectFolder = this.destinationPath().substring(this.destinationPath().lastIndexOf('\\')).replace("\\", "");
    this.fs.copyTpl(
      this.templatePath(templatePath),
      this.destinationPath('./')
    );
  }
}
