INSERT INTO beer(name, abv) VALUES('BrewDog Punk IPA', 5.6);
INSERT INTO beer(name, abv) VALUES('Stella Artois', 4.8);
INSERT INTO beer(name, abv) VALUES('Peroni', 5.1);

COMMIT;