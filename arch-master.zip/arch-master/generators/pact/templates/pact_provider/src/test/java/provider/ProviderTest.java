package provider;

import au.com.dius.pact.provider.junit.PactRunner;
import au.com.dius.pact.provider.junit.Provider;
import au.com.dius.pact.provider.junit.State;
import au.com.dius.pact.provider.junit.loader.PactFolder;
import au.com.dius.pact.provider.junit.target.HttpTarget;
import au.com.dius.pact.provider.junit.target.Target;
import au.com.dius.pact.provider.junit.target.TestTarget;
import org.junit.BeforeClass;
import org.junit.runner.RunWith;

@RunWith(PactRunner.class)
@Provider("test_provider") // provider service name
@PactFolder("../consumer/target/pacts") // PACT contract file location
public class ProviderTest {
    @TestTarget // denotes Target that will be used for tests
    public final Target target = new HttpTarget("http", "localhost", 8080);

    /* Specify the states in the contract we want to test referencing the provider states in the
    contract. Can also be used for setting the state of the test (such as data test is reliant on). */
    @State("test GET")
    public void toGetState() {
    }
}
