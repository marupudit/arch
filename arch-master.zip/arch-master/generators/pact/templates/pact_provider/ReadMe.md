# Contract Testing - Provider
## Overview
This sample project provides a working example of the provider side of contract testing. It consists of an app that exposes an endpoint providing data containing a listing of different types of beer and their associated alcohol content in JSON format and provider-side contract tests validating that the data provided by this service matches that expected by a downstream consumer.

This project makes use of the jvm implementation of PACT for a provider (pact-jvm - https://docs.pact.io/implementation_guides/jvm/provider/junit), which is one of the leading tools in the market for contract testing.

## Background
Contract testing validates that the data passed between a provider and consumer application are compatible. This is achieved by a consumer-driven test creating a contract that defines the structure and content of the data it expects to receive from a provider. This contract is then used by the provider to ensure that the data it generates is compatible with the consumer according the contract that was generated.

NOTE: This project only covers the provider side of contract testing. Refer to the `consumer` project in this accelerator to see an example for that part of the interaction.

## Installation

Prerequisites: Maven and compatible IDE (ie Intellij, Eclipse)

Compile project within IDE or terminal (run `mvn compile`)

## Provider Application
The provider service is a Spring Boot application. The code for this lies within the directory: `provider/src/main`

The service can be run by simply running the DemoApplication file at `provider/src/main/java/provider/DemoApplication`

After starting the app, navigate to the following URL in any browser to access the endpoint: 
- `http://localhost:8080/browser/index.html#/` will take you to an interface that provides detailed information, such as the Response Header and Body
- `http://localhost:8080/beers` will simple display the JSON the service exposes
- `http://localhost:8080/beers/1` - providing the index of the entry you want to retrieve will expose only the data for that given beer listing (in this case Brewdog Punk IPA)

If you desire to add more entries to the service, you will need to stop the application and make edits to the data.sql file (`provider/src/main/java/resources/data.sql`) and further Insert SQL queries:

- ie. `INSERT INTO beer(name, abv) VALUES('Budweiser', 5);`

## Provider Contract Tests

The provider contract test example lies in the directory: `provider/src/test`

Before running the provider side contract test, be sure that you have a generated contract, as this is the require input for the provider test to validate that the data it exposes is valid for the consumer. This means running the consumer contract test first, which is within the `consumer` project.

The provider test can be found in the following file `provider\src\test\java\provider\ProviderTest.java`.

Ensure that you provide file location for the contract for the `@PactFolder` annotation within this file. The default location for the contract will be within your consumer project in the path: `consumer\target\pacts`. After this has been done simply run `ProviderTest` to run the provider side contract test.

This particular example is just testing a GET response as this is all that this example service allows for, but the following documentation demonstrates how we could setup a test for a POST as well: https://www.baeldung.com/pact-junit-consumer-driven-contracts.

