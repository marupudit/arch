package consumer;

import au.com.dius.pact.consumer.Pact;
import au.com.dius.pact.consumer.PactProviderRuleMk2;
import au.com.dius.pact.consumer.PactVerification;
import au.com.dius.pact.consumer.dsl.DslPart;
import au.com.dius.pact.consumer.dsl.PactDslJsonBody;
import au.com.dius.pact.consumer.dsl.PactDslWithProvider;
import au.com.dius.pact.model.RequestResponsePact;
import org.apache.commons.lang.exception.NestableException;
import org.apache.http.client.ClientProtocolException;
import org.junit.Rule;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ConsumerTest {
    // Creating the mock server and passing the provider name, host and port on which it runs
    @Rule
    public PactProviderRuleMk2 mockProvider = new PactProviderRuleMk2("test_provider", "localhost", 8081, this);

    // Specify what you expect the service to provide
    @Pact(consumer = "test_consumer")
    public RequestResponsePact createPact(PactDslWithProvider builder) {
        Map<String, String> headers = new HashMap();
        headers.put("Content-Type", "application/hal+json");

        DslPart body = new PactDslJsonBody().stringType("name", "Stella Artois").numberType("abv", 4.8).asBody();

        return builder.given("test GET").uponReceiving("GET Request").path("/beers/2").method("GET").willRespondWith()
                .status(200).headers(headers).body(body).toPact();
    }

    /* Run the test in the context of the mock server which will generate the PACT.
     Default file location is "target/pacts" folder but can be configured */
    @Test
    @PactVerification("test_provider") // takes care of starting the HTTP service
    public void runTest() throws ClientProtocolException, IOException, NestableException {
        new ConsumerClient(mockProvider.getPort());
        String beerInfo = ConsumerClient.getStellaDetails();
        System.out.println(beerInfo);
        assertTrue(beerInfo.equals("Beer: Stella Artois, Abv: 4.8"));
    }

}
