package consumer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class ConsumerClient {
    static int port = 8080;

    public ConsumerClient() {
        System.out.println("Default port " + port);
    }

    ConsumerClient(int port) {
        this.port = port;
        System.out.println("Custom port " + port);
    }

    public static void main(String[] args) throws IOException {
        new ConsumerClient();
        String beerDetails = ConsumerClient.getStellaDetails();
        System.out.println(beerDetails);
    }

    private static String getStellaJson() {
        try {
            String url = String.format("http://localhost:%d/beers/2", port);
            URL obj = new URL(url);
            System.out.println("using url: " + url);
            HttpURLConnection con = (HttpURLConnection) obj.openConnection();
            con.setRequestMethod("GET");
            int responseCode = con.getResponseCode();
            System.out.println(responseCode);
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();
            return response.toString();
        } catch (Exception e) {
            System.out.println("Unable to get beer, error = " + e);
            return null;
        }
    }

    public static String getStellaDetails() {
        String data = getStellaJson();
        JSONObject jsonObject = new JSONObject(data);
        System.out.println(jsonObject);
        String beerName = jsonObject.getString("name").toString();
        Double beerAbv = jsonObject.getDouble("abv");
        String abvString = beerAbv.toString();
        String beerInfo = "Beer: " + beerName + ", Abv: " + abvString;
        return beerInfo;
    }

}
