# Contract Testing - Consumer
## Overview
This sample project provides a working example of the consumer side of contract testing. It consists of a consumer app that reads data from the provider service and prints out the beer name and alcohol content for a specific listing and the consumer-side contract tests validating that consumer app works according to the data that we expect to be provided to it.

This project makes use of the jvm implementation of PACT for a consumer (pact-jvm - https://docs.pact.io/implementation_guides/jvm/consumer/junit/), which is one of the leading tools in the market for contract testing.

## Background
Contract testing validates that the data passed between a provider and consumer application are compatible. This is achieved by a consumer-driven test creating a contract that defines the structure and content of the data it expects to receive from a provider. This contract is then used by the provider to ensure that the data it generates is compatible with the consumer according the contract that was generated.

NOTE: This project only covers the provider side of contract testing. Refer to the `consumer` project in this accelerator to see an example for that part of the interaction.

## Installation

Prerequisites: Maven and compatible IDE (ie Intellij, Eclipse)

Compile project within IDE or terminal (run `mvn compile`)

## Consumer Application

This consumer application is a simple program that makes a request to the provider service to retrieve information about a specific beer listing and writes the data to the console output. The code for this lies within the directory: `consumer/src/main`

In order for this application to run, ensure that the provider service is also running beforehand. Then run ConsumerClient at `consumer/src/main/java/consumer/ConsumerClient`. You will see the output with the beer name and abv written to the console as well as information including the URL endpoint that was pinged, the response code and JSON body.

## Consumer Contract Tests

The consumer contract test example lies in the directory: `consumer/src/test`

More detailed comments can be found in the file that specify the structure of the consumer test, but essentially this test validates that the consumer application runs properly based on the response it expects from the provider (ran against a mock server). A contract is created after the test passes which documents the interactions between the consumer and provider and is used as the input for the provider-side contract test to validate the data the provider generates matches that specified in the contract. The consumer test can be found in the following file `consumer\src\test\java\consumer\ConsumerTest`.

The contract generated should by default be found at the following path: `consumer\target\pacts`
