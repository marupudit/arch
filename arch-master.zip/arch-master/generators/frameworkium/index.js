'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {
 
  async prompting() {
    
    this.answers = await this.prompt([
      {
        type    : 'list',
        name    : 'testFormat',
        message : 'Select Cucumber if you want to use BDD format',
        choices : ['cucumber', 'standard']
      },
      {
      type    : 'input',
      name    : 'groupId',
      message : 'Enter the Maven GroupId',
    }
    ]);
  }

  writing() {
    var templatePath = `frameworkium_${this.answers.testFormat}`
    var projectFolder = this.destinationPath().substring(this.destinationPath().lastIndexOf('\\')).replace("\\", "");
    this.fs.copyTpl(
      this.templatePath(templatePath),
      this.destinationPath('./'),{
         projectName: projectFolder,
         groupId: this.answers.groupId
      }
    );
  }
}