To execute tests:

```mvn clean verify allure:serve -Dbrowser=chrome -DcustomBrowserImpl=com.custom.browser.impl.CustomChromeImpl -Dheadless=false -D"cucumber.filter.tags=not @ignore" -Denv=test```

Environment parameters can be updated in:

```src/test/resources/config.properties```