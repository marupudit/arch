package com.ten10.example.stepdefs;

import com.ten10.example.pages.Homepage;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Step;
import com.ten10.example.pages.Generic;
import com.ten10.example.pages.AcademyPage;

import static org.testng.AssertJUnit.assertEquals;

public class GenericStepdef {

    PagesApi pagesApi;

    public GenericStepdef(PagesApi pagesApi) {
        this.pagesApi = pagesApi;
        this.pagesApi.generic = new Generic();
    }

    @Step
    @Given("I am on the Ten10 homepage")
    public void i_am_on_the_ten10_homepage() {
        pagesApi.homepage = Homepage.open();
    }

    @Step
    @When("^I navigate to (.+)$")
    public void i_navigate_to(String page) throws Exception {
        if ("Academy".equals(page)) {
            pagesApi.academyPage = pagesApi.generic.navigateTo(
                    pagesApi.homepage.academyLink,
                    AcademyPage.class
            );
        }
    }

    @Step
    @Then("^The (.+) title matches '(.+)'$")
    public void the_title_matches(String page, String expectedTitle) {
        pagesApi.generic.waitForTitle(expectedTitle);
        String actualTitle = pagesApi.academyPage.getTitle();
        assertEquals(expectedTitle, actualTitle);
    }


}
