package com.ten10.example.pages;

import com.frameworkium.bdd.Config;
import com.frameworkium.core.htmlelements.element.Link;
import com.frameworkium.core.ui.annotations.Visible;
import com.frameworkium.core.ui.pages.BasePage;
import org.openqa.selenium.support.FindBy;

public class Homepage extends BasePage<Homepage> {

    @Visible
    @FindBy(css = "#menu-item-476 > a")
    public Link academyLink;

    public static Homepage open() {
        return new Homepage().get(Config.getProperty("baseUrl"));
    }

}
