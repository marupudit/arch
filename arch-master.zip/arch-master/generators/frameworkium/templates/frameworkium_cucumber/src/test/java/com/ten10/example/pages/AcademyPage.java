package com.ten10.example.pages;

import com.frameworkium.core.ui.pages.BasePage;

public class AcademyPage extends BasePage<AcademyPage> {

}

