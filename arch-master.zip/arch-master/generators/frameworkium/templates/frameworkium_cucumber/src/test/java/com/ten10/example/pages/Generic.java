package com.ten10.example.pages;

import com.frameworkium.bdd.Config;
import com.frameworkium.core.htmlelements.element.Link;
import com.frameworkium.core.ui.pages.BasePage;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.lang.reflect.InvocationTargetException;
import java.time.Duration;

public class Generic extends BasePage<Generic> {

    public <T extends BasePage<T>> T navigateTo(Link linkElement, Class<T> toPage) {
        try {
            String linkUrl = linkElement.getAttribute("href");
            return toPage.getDeclaredConstructor().newInstance().get(linkUrl);
        } catch (InstantiationException | IllegalAccessException | InvocationTargetException |
                 NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    public void waitForTitle(String title) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        try {
            wait.until(ExpectedConditions.titleIs(title));
        } catch (TimeoutException e) {
            Assert.fail(e.getMessage());
        }
    }

    public void maximiseWindow() {
        driver.manage().window().maximize();
    }
}
