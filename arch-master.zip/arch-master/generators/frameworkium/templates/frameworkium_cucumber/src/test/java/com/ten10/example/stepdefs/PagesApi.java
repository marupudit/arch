package com.ten10.example.stepdefs;

import com.ten10.example.pages.*;

public class PagesApi {

    Homepage homepage;
    Generic generic;
    AcademyPage academyPage;
}
