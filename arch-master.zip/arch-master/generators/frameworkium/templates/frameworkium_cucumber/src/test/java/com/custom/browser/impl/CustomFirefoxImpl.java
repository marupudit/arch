package com.custom.browser.impl;

import com.frameworkium.bdd.Config;
import com.frameworkium.core.ui.driver.drivers.FirefoxImpl;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.util.stream.Stream;

public class CustomFirefoxImpl extends FirefoxImpl {

    @Override
    public FirefoxOptions getCapabilities() {
        FirefoxOptions firefoxOptions = super.getCapabilities();
        Stream<String> browserConfig = Config.getBrowserConfig();

        //Add arguments and capabilities to firefoxOptions here...

        return firefoxOptions;
    }

    @Override
    public WebDriver getWebDriver(Capabilities capabilities) {
        WebDriverManager.firefoxdriver().setup();
        return super.getWebDriver(capabilities);
    }
}

