package com.custom.browser.impl;

import com.frameworkium.bdd.Config;
import com.frameworkium.core.ui.driver.drivers.ChromeImpl;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CustomChromeImpl extends ChromeImpl {

    @Override
    public ChromeOptions getCapabilities() {
        ChromeOptions chromeOptions = super.getCapabilities();
        Stream<String> browserConfig = Config.getBrowserConfig();

        // Add Chrome arguments from config
        chromeOptions.addArguments(
                browserConfig
                        .filter(s -> s.contains("argument"))
                        .map(Config::getProperty)
                        .collect(Collectors.toList()
                        ));

        return chromeOptions;
    }

    @Override
    public WebDriver getWebDriver(Capabilities capabilities) {
        WebDriverManager.chromedriver().setup();
        return super.getWebDriver(capabilities);
    }
}

