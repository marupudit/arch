package tests;

import com.frameworkium.core.ui.tests.BaseUITest;
import org.junit.Assert;
import org.testng.annotations.Test;
import ten10.configuration.Config;
import ten10.pages.AcademyPage;
import ten10.pages.HomePage;

import java.lang.reflect.InvocationTargetException;

import static org.testng.AssertJUnit.assertEquals;

public class ExampleTests extends BaseUITest {

    @Test(description = "Passing Test")
    public void PassingTest() {
        //arrange
        HomePage homePage;
        AcademyPage academyPage;
        String actualTitle;
        String expectedTitle = Config.getProperty("academyTitle");

        //act
        homePage = HomePage.open();

        try {
            academyPage = homePage.navigateTo(AcademyPage.class);
            actualTitle = academyPage.getTitle();

            //assert
            assertEquals(expectedTitle, actualTitle);
        } catch (NoSuchMethodException | InvocationTargetException | InstantiationException | IllegalAccessException e) {
            Assert.fail(e.getMessage());
        }
    }

    @Test(description = "Failing Test")
    public void FailingTest(){
        //arrange
        HomePage homePage;
        AcademyPage academyPage;
        String actualTitle;
        String expectedTitle = "Hello World";

        //act
        homePage = HomePage.open();

        try {
            academyPage = homePage.navigateTo(AcademyPage.class);
            actualTitle = academyPage.getTitle();

            //assert
            assertEquals(expectedTitle, actualTitle);
        } catch (NoSuchMethodException | InvocationTargetException | InstantiationException | IllegalAccessException e) {
            Assert.fail(e.getMessage());
        }
    }
}
