package ten10.configuration.impl;

import com.frameworkium.core.ui.driver.drivers.FirefoxImpl;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import ten10.configuration.Config;

import java.util.stream.Stream;

public class CustomFirefoxImpl extends FirefoxImpl {


    @Override
    public FirefoxOptions getCapabilities() {
        FirefoxOptions firefoxOptions = super.getCapabilities();
        String browser = System.getProperty("browser");
        Stream<String> browserConfig = Config.getBrowserConfig(browser);

        //Add arguments and capabilities to firefoxOptions here...

        return firefoxOptions;
    }

    @Override
    public WebDriver getWebDriver(Capabilities capabilities) {
        WebDriverManager.firefoxdriver().setup();
        return super.getWebDriver(capabilities);
    }
}

