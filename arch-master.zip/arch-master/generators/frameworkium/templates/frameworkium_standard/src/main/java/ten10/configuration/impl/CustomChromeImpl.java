package ten10.configuration.impl;

import com.frameworkium.core.ui.driver.drivers.ChromeImpl;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import ten10.configuration.Config;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CustomChromeImpl extends ChromeImpl {

    @Override
    public ChromeOptions getCapabilities() {
        ChromeOptions chromeOptions = super.getCapabilities();
        String browser = System.getProperty("browser");
        Stream<String> browserConfig = Config.getBrowserConfig(browser);

        // Add Chrome arguments from config
        chromeOptions.addArguments(
                browserConfig
                        .filter(s -> s.contains("argument"))
                        .map(Config::getProperty)
                        .collect(Collectors.toList()
                        ));

        return chromeOptions;
    }

    @Override
    public WebDriver getWebDriver(Capabilities capabilities) {
        WebDriverManager.chromedriver().setup();
        return super.getWebDriver(capabilities);
    }
}

