package ten10.pages;

import com.frameworkium.core.ui.annotations.Visible;
import com.frameworkium.core.ui.pages.BasePage;
import com.frameworkium.core.ui.pages.PageFactory;
import jdk.jfr.Name;
import ten10.configuration.Config;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import io.qameta.allure.Step;

import java.lang.reflect.InvocationTargetException;

public class HomePage extends BasePage<HomePage> {

    @Visible
    @Name("Academy Link")
    @FindBy(css = "#menu-item-476 > a")
    private WebElement academyLink;

    public static HomePage open() {
        return PageFactory.newInstance(HomePage.class, Config.getProperty("baseUrl"));
    }

    public <T extends BasePage<T>> T navigateTo(Class<T> page) throws NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {
        if(page == AcademyPage.class){
            academyLink.click();
        }
        return page.getDeclaredConstructor().newInstance().get();
    }
}
