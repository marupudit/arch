package ten10.pages;

import com.frameworkium.core.ui.pages.BasePage;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ten10.configuration.Config;

import java.time.Duration;

public class AcademyPage extends BasePage<AcademyPage> {

    AcademyPage() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.titleIs(Config.getProperty("academyTitle")));
    }

    // Fill with page elements and methods
}
