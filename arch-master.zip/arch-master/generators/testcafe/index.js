'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {
 
  async prompting() {
    
    
    this.answers = await this.prompt([
      {
        type    : 'list',
        name    : 'testFormat',
        message : 'Select Cucumber if you want to use BDD format with TestCafe',
        choices : ['cucumber', 'standard']
      },
      {
        type    : 'input',
        name    : 'projectName',
        message : 'Enter the project name',
      },
      {
        type    : 'input',
        name    : 'projectCode',
        message : 'Enter the project code',
      },
      {
      type    : 'input',
      name    : 'baseUrl',
      message : 'Enter the project base url',
      },
      {
        type    : 'input',
        name    : 'projectAuthor',
        default : 'Ten10',
        message : 'Enter the name of the project author',
      },
      {
        type    : 'input',
        name    : 'projectDescription',
        default : 'Provide description here',
        message : 'Enter a project description',
      }
    ]);
  }

  writing() {
    
    var templatePath = `testcafe_${this.answers.testFormat}`
    this.fs.copy(
      this.templatePath(templatePath),
      this.destinationPath('./'),
    );
    this.fs.copy(
      this.templatePath('config.js'),
      this.destinationPath('config.js'),
    );
    this.fs.copyTpl(
      this.templatePath('config-generated.js'),
      this.destinationPath('config-generated.js'),
      { baseUrl: this.answers.baseUrl,
      projectCode: this.answers.projectCode } 
    );
    this.fs.copyTpl(
      this.templatePath(templatePath+'/package.json'),
      this.destinationPath('package.json'),
      { baseUrl: this.answers.baseUrl,
      projectName: this.answers.projectName, 
      projectAuthor: this.answers.projectAuthor,
      projectDescription: this.answers.projectDescription
     } 
    );
  }

  install() {
    this.npmInstall();
  }
}