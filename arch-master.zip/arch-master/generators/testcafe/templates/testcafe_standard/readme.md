# Testcafe Project Template

Tests written using [Testcafe](https://devexpress.github.io/testcafe/) - A node.js tool to automate end-to-end web testing

# Prerequisites

[Node.js](https://nodejs.org/en/)
[npm](https://www.npmjs.com/)

# Installation

All dependencies will be installed by running

```
npm install 
```

# Project Structure
```
project
|-- pages        <!--- Page Object Layer (Update to reflect your page objects --->
|   -- basepage.js 
|   -- homepage.js
|-- tests         <!--- Test Layer (Update to reflect your test scenarios)--->
|   -- exampletest.js
|-- config.js
|-- package.json
|-- readme.md
```
# Running tests

To run example tests:

```
node runner
```

# Configuration
Configuration is provided in the config.js file, use the default section for shared configuration & add to/create new environment variables. 

Run time parameters can be passed by appending --KEY=VALUE to the end of the run command, these will be apended to the exisitng config and can be accessed using config.KEY throughout the project.

Further runtime configuration can be viewed in the testcafe docs

# Capturing Performance Metrics

All that is required to capture performance metrics is calling getMetrics("Transaction Name") after a user action and it will be availbale to view in influx/Grafana.

Metrics are not captured by default (to avoid spamming Influx whilst creating/debugging scripts). To enable metric capturing add the following key/value:

**--captureMetrics=true**