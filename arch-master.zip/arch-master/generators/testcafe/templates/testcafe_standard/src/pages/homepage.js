import { Selector, t } from "testcafe";
import BasePage from "./basepage";

export default class HomePage extends BasePage {
  constructor() {
    super();
    this.techAcademyLink = Selector("#menu-item-476 > a");
    this.contactLink = Selector("#menu-item-4956 > a");
  }


  async clickLink(linkText) {
    switch (linkText) {
      case "Tech Academy":
        await t.click(this.techAcademyLink);
        break;
      case "Contact":
        await t.click(this.contactLink);
        break;
      default:
        await t.click(Selector("a").withText(linkText));
    }
  }
}
