import { Selector, t } from 'testcafe';

export default class BasePage {
    constructor () {
        this.title = Selector('title')
    }
}