const Influx = require('influx');
var config = require('../config')
var timer = require('marky');

const influx = new Influx.InfluxDB({
  host: config.influxHost,
  database: config.influxDatabase,
  port: config.influxPort,
});

function writeToInflux(transactionName, responseTime) {
  influx.writePoints([
    {
      measurement: config.influxTable,
      tags: {label: transactionName},
      fields: {
        value: responseTime,
      },
    },
  ]);
}

async function captureResponseTime(transactionName, fn) {
        
  timer.mark(transactionName)
  await fn
  var entry = timer.stop(transactionName)
  if(JSON.parse(config.captureMetrics || false)){
      writeToInflux(transactionName, entry.duration)
  }
  
}

module.exports = { captureResponseTime };