import { t } from 'testcafe';
import config from '../../config'
import BasePage from '../pages/basepage'
import HomePage from '../pages/homepage'

const homepage = new HomePage();
const basePage = new BasePage();

fixture('Navigation Tests')
.page(`${config.baseUrl}`)

test('Navigate to Academy Page', async t => {
    
    await homepage.clickLink("Tech Academy")
    await t.expect(basePage.title.innerText).contains("Tech Academy - Ten10")
})

test('Navigate to Contact', async t => {
    
    await homepage.clickLink("Contact")
    await t.expect(basePage.title.innerText).contains("Contact - Ten10")
})

test('Failing test to show screenshot', async t => {
    
    await homepage.clickLink("Contact")
    await t.expect(basePage.title.innerText).contains("The Application Process - Apply Today")
})

