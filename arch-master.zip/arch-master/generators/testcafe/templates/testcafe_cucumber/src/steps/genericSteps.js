const { Given, When, Then, Before } = require('@cucumber/cucumber');
const basePage = require('../pages/basepage');

Then(/^The title matches '(.+)'$/, async (t,title) => {
    const actualTitle = basePage.elements.title().innerText;
    await t.expect(actualTitle).contains(title[0], {timeout: 5000});
})