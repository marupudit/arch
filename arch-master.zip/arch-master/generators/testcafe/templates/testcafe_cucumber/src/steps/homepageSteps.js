const { Given, When, Then, Before } = require('@cucumber/cucumber');
const {Selector} = require('testcafe');
const homePage = require('../pages/homepage');
const config = require('../../config');

Given('I am on the Ten10 homepage', async function(t) {
    await t.navigateTo(`${config.baseUrl}`);
})

When(/^I click (.+)$/, async function(t ,linkText) {
    switch (linkText[0]) {
        case 'Tech Academy':
            await t.click(homePage.elements.techAcademyLink());
            break;
        case 'Contact':
            await t.click(homePage.elements.contactLink());
            break;
        default:
            await t.click(Selector('a').withText(linkText[0]));
    }
})


