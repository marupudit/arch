const { Selector } = require("testcafe");

exports.elements = {
  title: function () {
    return Selector("title");
  }
};
