const { Selector } = require("testcafe");

exports.elements = {
  techAcademyLink: function () {
    return Selector("#menu-item-476 > a");
  },
  contactLink: function () {
    return Selector("#menu-item-4956 > a");
  }
};
