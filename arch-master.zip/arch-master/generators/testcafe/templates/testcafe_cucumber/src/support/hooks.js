const {Before, After, BeforeAll, AfterAll} = require('@cucumber/cucumber'); 

Before("@example", async (t) => {
    await t.maximizeWindow();
})