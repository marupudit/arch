# Testcafe Project Template using Cucumber

Tests written using [Testcafe](https://devexpress.github.io/testcafe/) via the [testcafe-cucumber](https://github.com/rquellh/testcafe-cucumber) wrapper. For more information on Cucumber see [https://cucumber.io/](https://cucumber.io/)

# Prerequisites

[Node.js](https://nodejs.org/en/)
[npm](https://www.npmjs.com/)

# Installation

All dependencies will be installed by running

```
npm install
```

# Project Structure

```
project
|-- src
|   -- features     <!--- Contains all Cucumber feature files --->
|   -- pages        <!--- Conatins all page objects --->
|   -- steps        <!--- Contains the step code>
|   -- support
|      -- hooks.js      <!--- Used to perform actions before a test scenario  --->
|      -- reportGeneration.js <!--- Used to generate html report --->
|      -- config.js    <!--- Contains all config values --->
|   -- example.feature <!--- Feature file containing gherkin style tests --->
|-- package.json
|-- readme.md
|-- testcafe-reporter-cucumber-json.json <!--- Config for reports --->
```

# Running tests

To run example tests:

```
npm run exampleChrome
```

# Configuration

Configuration is provided in the config.js file, use the default section for shared configuration & add to/create new environment variables.

Run time parameters can be passed by appending --KEY=VALUE to the end of the run command, these will be apended to the exisitng config and can be accessed using config.KEY throughout the project.

Further runtime configuration can be viewed in the testcafe docs
