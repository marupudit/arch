const _ = require("lodash");
var argv = require("minimist")(process.argv.slice(2));
var env = argv.env || "dev";

// Specific Environment Variables
// Specific Environment Variables
const dev = {
  baseUrl: "https://www.ten10.com/",
};

const test = {
  baseUrl: "https://www.ten10.com/",
};

// Default Shared config
const defaultConfig = {
  influxHost: "grafana.ten10.com",
  influxPort: 8086,
  influxDatabase: "datasource",
  influxTable: "testcafe.TEN1234.timings", // Change TEN1234 to Project Code
};

const environment = {
  dev,
  test,
};

var finalConfig = _.merge(defaultConfig, environment[env], argv);

module.exports = finalConfig;
