const _ = require('lodash');
var argv = require('minimist')(process.argv.slice(2));
var env = argv.env || "dev" 

// Specific Environment Variables
const dev = {
    "baseUrl": "<%= baseUrl %>"
  };
  
  const test = {
    "baseUrl": "<%= baseUrl %>"
  }

// Default Shared config
const defaultConfig = {
  "influxHost": "grafana.ten10.com",
  "influxPort":8086,
  "influxDatabase":"datasource", 
  "influxTable": "testcafe.<%= projectCode %>.timings" 
 };


 const environment = {
  dev,
  test
 }

var finalConfig = _.merge(defaultConfig, environment[env], argv);

module.exports = finalConfig;
 