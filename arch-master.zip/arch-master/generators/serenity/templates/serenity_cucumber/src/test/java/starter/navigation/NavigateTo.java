package starter.navigation;

import net.serenitybdd.core.annotations.findby.FindBy;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.Step;
import org.w3c.dom.Text;
import starter.matchers.TextMatcher;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

public class NavigateTo extends PageObject {

    Ten10Homepage ten10Homepage;

    @FindBy(css = "h1")
    private WebElementFacade pageHeader;

    @Step("Open the Ten10 home page")
    public void ten10HomePage() {
        ten10Homepage.open();
    }

    public void assertPageIsDisplayed(String page) {
        assertThat(pageHeader.getText().equalsIgnoreCase(page), is(true));
    }
}