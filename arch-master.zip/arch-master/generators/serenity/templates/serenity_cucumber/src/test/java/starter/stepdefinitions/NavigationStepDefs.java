package starter.stepdefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.thucydides.core.annotations.Steps;
import starter.navigation.NavigateTo;
import starter.pages.Homepage;

import static jnr.posix.util.MethodName.getMethodName;
import static net.serenitybdd.core.Serenity.pendingStep;

public class NavigationStepDefs {

    @Steps
    NavigateTo navigateTo;

    @Steps
    Homepage homepage;

    @Given("I am on the Ten10 home page")
    public void navigateToTheTenHomePage() {
        navigateTo.ten10HomePage();
    }

    @When("I click on {string}")
    public void click(String name) {
        switch (name.toUpperCase()) {
            case "SERVICES":
                homepage.clickServicesLink();
                break;
            default:
                pendingStep(name + " is not defined within " + getMethodName());
        }
    }

    @Then("the {string} page is displayed")
    public void thePageIsDisplayed(String page) throws Throwable {
        navigateTo.assertPageIsDisplayed(page);
    }
}
