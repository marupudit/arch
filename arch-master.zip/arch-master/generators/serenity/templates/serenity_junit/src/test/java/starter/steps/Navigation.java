package starter.steps;

import net.thucydides.core.annotations.Step;
import org.openqa.selenium.WebDriver;

public class Navigation {

    String actor;

    WebDriver driver;

    @Step("#actor navigates to the {site}")
    public void navigateToSite(String site) {
        driver.get(site);
    }
}