package starter.navigation;

import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Managed;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import starter.steps.Navigation;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.openqa.selenium.support.ui.ExpectedConditions.titleContains;

@RunWith(SerenityRunner.class)

public class OpenDefaultUrlTest {

    OpenDefaultUrl openDefaultUrl;

    @Managed
    WebDriver driver;

    @Steps
    Navigation user;

    @Test
    public void NavigateToSite() {

        openDefaultUrl.open();

        new WebDriverWait(driver,5).until(titleContains("Quality Technology Change"));

        assertThat(driver.getTitle(),containsString("Quality Technology Change"));

    }

}
