﻿
using FlaUIAutomation.PageObjects;
using System;
using FlaUI.Core.Tools;
using NUnit.Framework;
using FlaUIAutomation.Tests;

namespace FlaUIAutomation
{

    public class ExampleTests : BaseTest
    {
        //Passing
        [Test]
        public void WriteToDoc()
        {
            var notePad = new NotePadPage();
            var text = "Hello World!";

            Assert.AreEqual("", notePad.GetText);

            notePad.TypeInTextBox(text);
            Retry.WhileTrue(() => notePad.GetText == "", TimeSpan.FromSeconds(2));
            Assert.AreEqual(text, notePad.GetText);
            
        }

        //Failing 
        [Test]
        public void ViewAboutPage()
        {
            var notePad = new NotePadPage();
            var aboutPage = new AboutPage();
            var aboutText = "Hello World!";
            notePad.NavigateToAboutPage(); 
            Retry.WhileNull(() => new AboutPage(), TimeSpan.FromSeconds(5));

            Assert.AreEqual(aboutText, aboutPage.GetAboutText); 
        }
    }
}
