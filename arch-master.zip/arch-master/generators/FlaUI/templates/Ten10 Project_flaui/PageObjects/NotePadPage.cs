﻿using FlaUI.Core.AutomationElements;
using FlaUIAutomation.BaseElement;

namespace FlaUIAutomation.PageObjects
{
    class NotePadPage : BasePage
    {

        public NotePadPage() : base()
        {
            SetWindow();
        }

        //UIElements
        #region
        private MainMenuElement MainMenu => new MainMenuElement();
        private TextBox TextBox => new UIElement<TextBox>("Text Editor", IdentifierType.name).element;
        private TitleBar TitleBar => new UIElement<TitleBar>("TitleBar", IdentifierType.automationId).element;
        private Grid StatusBar => new UIElement<Grid>("StatusBar", IdentifierType.automationId).element;

        private class MainMenuElement
        { 
            public Menu Main => new UIElement<Menu>("MenuBar", IdentifierType.automationId).element;

            public MenuItem File => Main.Items[0];
            public MenuItem Edit => Main.Items[1];
            public MenuItem Format => Main.Items[2];
            public MenuItem View => Main.Items[3];
            public MenuItem Help => Main.Items[4];

        }
        #endregion

        //Methods 
        #region

        public void TypeInTextBox(string text) => TextBox.Enter(text);

        public AboutPage NavigateToAboutPage()
        {
            MainMenu.Help.Items[2].Invoke();
            return new AboutPage();
        }

        #endregion

        //Scrapers
        #region 

        public string GetText => TextBox.Text;

        #endregion
    }
}
