﻿using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.UIA2;
using System.Diagnostics;

namespace FlaUIAutomation.PageObjects
{
    class BasePage
    {
        public static Window Window { get; set; }
        private static Application App { get; set; }
        private static UIA2Automation Automation  { get; set; }

        public static void LaunchApp()
        {
            Automation = new UIA2Automation();
            var si = new ProcessStartInfo();
            si.LoadUserProfile = false;
            si.UseShellExecute = false;
            si.FileName = @"C:\Windows\notepad.exe";
            App = Application.Launch(si);
            Window = App.GetMainWindow(Automation);
        }

        public static void SetWindow()
        {
            Window = App.GetMainWindow(Automation);
        }

        public static Window[] GetTopLevelWindows()
        {
            return App.GetAllTopLevelWindows(Automation);
        }

        public static void KillApp()
        {
            if (App != null) { App.Kill(); }
        }
    }
}

