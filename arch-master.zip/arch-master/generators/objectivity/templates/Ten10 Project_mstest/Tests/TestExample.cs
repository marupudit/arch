﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ten10_Project_mstest.Framework;
using Ten10_Project_mstest.PageObjects;

namespace Ten10_Project_mstest
{
    /// <summary>
    /// Test class.
    /// </summary>
    [TestClass]
    public class TestExample : ProjectTestBase
    {
        /// <summary>
        /// Passing test - Navigate to the Ten10 Academy Page
        /// </summary>
        [TestMethod]
        public void NavigateToAcademyPage()
        {
            // Arrange
            AcademyPage academyPage;
            var expectedTitle = "Tech Academy - Ten10";
            var homePage = new HomePage(DriverContext);

            // Act
            homePage.OpenHomePage();
            academyPage = homePage.GoToPage<AcademyPage>();

            // Assert
            academyPage.TitleIs(expectedTitle);
        }

        /// <summary>
        /// Failing test - Navigate to the Ten10 Academy Page
        /// </summary>
        [TestMethod]
        public void NavigateToAcademyPageFailing()
        {
            // Arrange
            AcademyPage academyPage;
            var expectedTitle = "Hello World";
            var homePage = new HomePage(DriverContext);

            // Act
            homePage.OpenHomePage();
            academyPage = homePage.GoToPage<AcademyPage>();

            // Assert
            academyPage.TitleIs(expectedTitle);
        }
    }
}

