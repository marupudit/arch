﻿using NLog;
using Ocaramba;
using Ocaramba.Extensions;
using Ocaramba.Types;
using System;
using System.Globalization;
using Ten10_Project_mstest.Framework;

namespace Ten10_Project_mstest.PageObjects
{
    /// <summary>
    /// Page object class.
    /// </summary>
    public class HomePage : ProjectPageBase
    {
        private static readonly Logger Logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        /// <summary>
        /// Locators for elements.
        /// </summary>
        private readonly ElementLocator
            academyLink = new ElementLocator(Locator.CssSelector, "#menu-item-476 > a");

        /// <summary>
        /// Initializes a new instance of the <see cref="HomePage"/> class.
        /// </summary>
        /// <param name="driverContext">Base driverContext.</param>
        public HomePage(DriverContext driverContext)
            : base(driverContext)
        {

        }

        /// <summary>
        /// Methods for this HomePage.
        /// </summary>
        public void OpenHomePage()
        {
            var url = BaseConfiguration.GetUrlValue;
            Logger.Info(CultureInfo.CurrentCulture, "Opening page {0}", url);
            Driver.NavigateTo(new Uri(url));
        }

        /// <summary>
        /// Go to page.
        /// </summary>
        public T GoToPage<T>() where T : ProjectPageBase
        {
            Logger.Info(CultureInfo.CurrentCulture, "Clicking on element link");
            ElementLocator link = typeof(T) switch
            {
                Type type when type == typeof(AcademyPage) => academyLink,
                _ => throw new NotImplementedException("The Page Object, " + typeof(T).ToString() + ", has not been implimented."),
            };
            Driver.GetElement(link).Click();
            return (T)Activator.CreateInstance(typeof(T), DriverContext);
        }
    }
}
