﻿// <copyright file="ProjectTestBase.cs" company="Objectivity Bespoke Software Specialists">
// Copyright (c) Objectivity Bespoke Software Specialists. All rights reserved.
// </copyright>
// <license>
//     The MIT License (MIT)
//     Permission is hereby granted, free of charge, to any person obtaining a copy
//     of software and associated documentation files (the "Software"), to deal
//     in the Software without restriction, including without limitation the rights
//     to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//     copies of the Software, and to permit persons to whom the Software is
//     furnished to do so, subject to the following conditions:
//     The above copyright notice and permission notice shall be included in all
//     copies or substantial portions of the Software.
//     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//     IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//     FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//     AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//     LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//     OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//     SOFTWARE.
// </license>

using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Ocaramba;
using Ocaramba.Logger;

namespace Ten10_Project_mstest.Framework
{
    /// <summary>
    /// The base class for all tests <see href="https://github.com/ObjectivityLtd/Ocaramba/wiki/ProjectTestBase-class">More details on wiki</see>
    /// </summary>
    [TestClass]
    public class ProjectTestBase : TestBase
    {
        private readonly DriverContext driverContext = new DriverContext();

        /// <summary>
        /// Gets or sets logger instance for driver
        /// </summary>
        public TestLogger LogTest
        {
            get
            {
                return DriverContext.LogTest;
            }

            set
            {
                DriverContext.LogTest = value;
            }
        }

        /// <summary>
        /// Gets or sets the microsoft test context.
        /// </summary>
        /// <value>
        /// The microsoft test context.
        /// </value>
        public TestContext TestContext { get; set; }

        /// <summary>
        /// Gets the driver context
        /// </summary>
        protected DriverContext DriverContext
        {
            get
            {
                return driverContext;
            }
        }

        /// <summary>
        /// Before the test.
        /// </summary>
        [TestInitialize]
        public void BeforeTest()
        {
            DriverContext.CurrentDirectory = AppDomain.CurrentDomain.BaseDirectory;
            DriverContext.TestTitle = TestContext.TestName;
            LogTest.LogTestStarting(driverContext);
            DriverContext.Start();
        }

        /// <summary>
        /// After the test.
        /// </summary>
        [TestCleanup]
        public void AfterTest()
        {
            DriverContext.IsTestFailed = TestContext.CurrentTestOutcome == UnitTestOutcome.Failed || !driverContext.VerifyMessages.Count.Equals(0);
            var filePaths = SaveTestDetailsIfTestFailed(driverContext);
            SaveAttachmentsToTestContext(filePaths);
            var javaScriptErrors = DriverContext.LogJavaScriptErrors();
            DriverContext.Stop();
            LogTest.LogTestEnding(driverContext);
            if (IsVerifyFailedAndClearMessages(driverContext) && TestContext.CurrentTestOutcome != UnitTestOutcome.Failed)
            {
                Assert.Fail("Look at stack trace logs for more details");
            }

            if (javaScriptErrors)
            {
                Assert.Fail("JavaScript errors found. See the logs for details");
            }
        }

        private void SaveAttachmentsToTestContext(string[] filePaths)
        {
            if (filePaths != null)
            {
                foreach (var filePath in filePaths)
                {
                    LogTest.Info("Uploading file [{0}] to test context", filePath);
                    TestContext.AddResultFile(filePath);
                }
            }
        }
    }
}