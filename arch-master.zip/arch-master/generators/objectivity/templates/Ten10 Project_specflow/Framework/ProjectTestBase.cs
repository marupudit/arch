﻿// <copyright file="ProjectTestBase.cs" company="Objectivity Bespoke Software Specialists">
// Copyright (c) Objectivity Bespoke Software Specialists. All rights reserved.
// </copyright>
// <license>
//     The MIT License (MIT)
//     Permission is hereby granted, free of charge, to any person obtaining a copy
//     of software and associated documentation files (the "Software"), to deal
//     in the Software without restriction, including without limitation the rights
//     to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
//     copies of the Software, and to permit persons to whom the Software is
//     furnished to do so, subject to the following conditions:
//     The above copyright notice and permission notice shall be included in all
//     copies or substantial portions of the Software.
//     THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
//     IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
//     FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
//     AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
//     LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
//     OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
//     SOFTWARE.
// </license>

using System.IO;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using Ocaramba;
using Ocaramba.Logger;
using AventStack.ExtentReports;
using System;
using TechTalk.SpecFlow;
using AventStack.ExtentReports.Reporter;
using AventStack.ExtentReports.Reporter.Configuration;
using System.Diagnostics;

namespace Ten10_Project_specflow.Framework
{
    /// <summary>
    /// The base class for all tests <see href="https://github.com/ObjectivityLtd/Ocaramba/wiki/ProjectTestBase-class">More details on wiki</see>
    /// </summary>
    [Binding]
    public class ProjectTestBase : TestBase
    {
        private const string extentOutput = "\\TestOutput\\index.html";
        private readonly DriverContext driverContext = new DriverContext();
        private readonly ScenarioContext scenarioContext;
        private static ExtentTest testContainer;
        private static ExtentReports extent;
        protected static ExtentTest test;

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectTestBase"/> class.
        /// </summary>
        /// <param name="scenarioContext"> Scenario Context </param>
        public ProjectTestBase(ScenarioContext scenarioContext)
        {
            if (scenarioContext == null)
            {
                throw new ArgumentNullException("scenarioContext");
            }

            this.scenarioContext = scenarioContext;
        }

        /// <summary>
        /// Gets or sets logger instance for driver
        /// </summary>
        public TestLogger LogTest
        {
            get
            {
                return DriverContext.LogTest;
            }

            set
            {
                DriverContext.LogTest = value;
            }
        }

        /// <summary>
        /// Gets or Sets the driver context
        /// </summary>
        protected DriverContext DriverContext
        {
            get
            {
                return driverContext;
            }
        }

        /// <summary>
        /// Method executed once only before all the tests are started
        /// </summary>
        [BeforeTestRun]
        public static void BeforeSuite()
        {
            extent = new ExtentReports();
            var reporter = new ExtentHtmlReporter(Directory.GetCurrentDirectory() + extentOutput);
            reporter.Config.ReportName = "Ocaramba UITests Report - " + BaseConfiguration.TestBrowser;
            reporter.Config.Theme = Theme.Standard;
            extent.AttachReporter(reporter);
        }

        /// <summary>
        /// Method executed once only after all the tests are finished
        /// </summary>
        [AfterTestRun]
        public static void AfterSuite()
        {
            extent.Flush();
            Process process = new Process()
            {
                StartInfo = new ProcessStartInfo()
                {
                    WindowStyle = ProcessWindowStyle.Hidden,
                    FileName = "cmd.exe",
                    Arguments = string.Format("/C start \"\" \"{0}\"", Directory.GetCurrentDirectory() + extentOutput)
                }
            };
            process.Start();
        }

        /// <summary>
        /// Before the Feature 
        /// </summary>
        /// <param name="featureContext"></param>
        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            testContainer = extent.CreateTest(featureContext.FeatureInfo.Title);
        }

        /// <summary>
        /// After the Feature.
        /// </summary>
        [AfterFeature]
        public static void AfterFeature()
        {
        }


        /// <summary>
        /// Before the Scenario.
        /// </summary>
        [BeforeScenario]
        public void BeforeScenario()
        {
            var scenarioTitle = scenarioContext.ScenarioInfo.Title;
            test = testContainer.CreateNode(scenarioTitle);
            DriverContext.TestTitle = scenarioTitle;
            LogTest.LogTestStarting(driverContext);
            DriverContext.Start();
            scenarioContext["DriverContext"] = DriverContext;
        }

        /// <summary>
        /// After the Scenario.
        /// </summary>
        [AfterScenario]
        public void AfterScenario()
        {
            var status = TestContext.CurrentContext.Result.Outcome.Status;
            DriverContext.IsTestFailed = status == TestStatus.Failed || !driverContext.VerifyMessages.Count.Equals(0);
            var filePaths = SaveTestDetailsIfTestFailed(driverContext);
            SaveAttachmentsToTestContext(filePaths);
            LogTest.LogTestEnding(driverContext);
            var javaScriptErrors = DriverContext.LogJavaScriptErrors();
            if (IsVerifyFailedAndClearMessages(driverContext) && status != TestStatus.Failed)
            {
                Assert.Fail();
            }

            if (javaScriptErrors)
            {
                Assert.Fail("JavaScript errors found. See the logs for details");
            }
            if (status == TestStatus.Failed)
            {
                test.Fail(status + ": " + scenarioContext.TestError.Message);
                EmbedAttachmentsToExtentReport(filePaths);
            }
            else
            {
                test.Pass("Test Passed");
            }
            DriverContext.Stop();
        }

        private void SaveAttachmentsToTestContext(string[] filePaths)
        {
            if (filePaths != null)
            {
                foreach (var filePath in filePaths)
                {
                    LogTest.Info("Uploading file [{0}] to test context", filePath);
                    TestContext.AddTestAttachment(filePath);
                }
            }
        }
        private void EmbedAttachmentsToExtentReport(string[] filePaths)
        {
            if (filePaths != null)
            {
                foreach (var filePath in filePaths)
                {
                    string filename = Path.GetFileName(filePath);
                    test.AddScreenCaptureFromPath(".\\" + filename);
                }
            }
        }
    }
}