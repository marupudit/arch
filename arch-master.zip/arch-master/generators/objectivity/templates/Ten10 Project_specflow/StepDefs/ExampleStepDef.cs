﻿using NUnit.Framework;
using Ocaramba;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using TechTalk.SpecFlow;
using Ten10_Project_specflow.PageObjects;

namespace Ten10_Project_specflow.StepDefs
{
    [Binding]
    class ExampleStepDef
    {
        private readonly DriverContext driverContext;
        private readonly ScenarioContext scenarioContext;
        private HomePage home;

        public ExampleStepDef(ScenarioContext scenarioContext)
        {
            if (scenarioContext == null)
            {
                throw new ArgumentNullException("scenarioContext");
            }

            this.scenarioContext = scenarioContext;

            driverContext = this.scenarioContext["DriverContext"] as DriverContext;
            home = new HomePage(driverContext);
        }

        [Given("I am on the Ten10 homepage")]
        public void IAmOnTheTen10Homepage()
        {
            home.OpenHomePage();
        }

        [When("I click the (.+) button")]
        public void IClickTheButton(string buttonName)
        {
            switch (buttonName)
            {
                case "Academy":
                    _ = home.GoToPage<AcademyPage>();
                    return;
                case "Contacts":
                    _ = home.GoToPage<ContactPage>();
                    return;
                default:
                    break;
            }
        }

        [Then("The page title is \"(.+)\"")]
        public void ThePageTitleIs(string expectedTitle)
        {
            var driver = driverContext.Driver;
            var wait = new WebDriverWait(driver, TimeSpan.FromSeconds(BaseConfiguration.MediumTimeout));

            try
            {
                wait.Until(condition =>
                {
                    try { return driver.Title == expectedTitle; }
                    catch (Exception) { return false; }
                });
            }
            catch (WebDriverTimeoutException) { /*Ignored so assertion can fail*/ }

            Assert.AreEqual(expectedTitle, driver.Title);
        }
    }
}
