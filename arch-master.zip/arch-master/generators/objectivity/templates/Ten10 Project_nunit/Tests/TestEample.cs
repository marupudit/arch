﻿
using NUnit.Framework;
using Ten10_Project_nunit.Framework;
using Ten10_Project_nunit.PageObjects;

namespace Ten10_Project_nunit
{
    /// <summary>
    /// Test class.
    /// </summary>
    [TestFixture]
    [Parallelizable(ParallelScope.Fixtures)]
    public class TestEample : ProjectTestBase
    {
        /// <summary>
        /// Passing test - Navigate to the Ten10 Academy Page
        /// </summary>
        [Test]
        public void NavigateToAcademyPage()
        {
            // Arrange
            AcademyPage academyPage;
            var expectedTitle = "Tech Academy - Ten10";
            var homePage = new HomePage(DriverContext);

            // Act
            homePage.OpenHomePage();
            academyPage = homePage.GoToPage<AcademyPage>();

            // Assert
            academyPage.TitleIs(expectedTitle);
        }

        /// <summary>
        /// Failing test - Navigate to the Ten10 Academy Page
        /// </summary>
        [Test]
        public void NavigateToAcademyPageFailing()
        {
            // Arrange
            AcademyPage academyPage;
            var expectedTitle = "Hello World";
            var homePage = new HomePage(DriverContext);

            // Act
            homePage.OpenHomePage();
            academyPage = homePage.GoToPage<AcademyPage>();

            // Assert
            academyPage.TitleIs(expectedTitle);
        }
    }
}
