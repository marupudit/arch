﻿using NLog;
using Ocaramba;
using Ten10_Project_nunit.Framework;

namespace Ten10_Project_nunit.PageObjects
{
    /// <summary>
    /// Page object class.
    /// </summary>
    public class AcademyPage : ProjectPageBase
    {
        private readonly Logger Logger = NLog.Web.NLogBuilder.ConfigureNLog("nlog.config").GetCurrentClassLogger();

        /// <summary>
        /// Initializes a new instance of the <see cref="AcademyPage"/> class.
        /// </summary>
        /// <param name="driverContext">Base driverContext.</param>
        public AcademyPage(DriverContext driverContext)
            : base(driverContext)
        {

        }
    }
}

