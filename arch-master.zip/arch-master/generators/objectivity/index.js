'use strict';
const Generator = require('yeoman-generator');

module.exports = class extends Generator {
 
  async prompting() {
    this.answers = await this.prompt([{
      type    : 'list',
      name    : 'testRunner',
      message : 'Which test runner do you want to use?',
      choices : ['specflow', 'nunit', 'mstest']
    }
    ]);
  }

  
  writing() {
    var projectFolder = this.destinationPath().substring(this.destinationPath().lastIndexOf('\\')).replace("\\", "");
    this.fs.copy(
      this.templatePath(`Ten10 Project_${this.answers.testRunner}`),
      this.destinationPath(`${projectFolder}`),
    );
    this.fs.delete(this.destinationPath(`${projectFolder}/Ten10 Project_${this.answers.testRunner}.csproj`))
    this.fs.copyTpl(
      this.templatePath(`Ten10 Project_${this.answers.testRunner}/Ten10 Project_${this.answers.testRunner}.csproj`),
      this.destinationPath(`${projectFolder}/${projectFolder}.csproj`),{
        projectName: projectFolder
      }
    );
    this.fs.copyTpl(
      this.templatePath(`Ten10 Project_${this.answers.testRunner}/Properties/AssemblyInfo.cs`),
      this.destinationPath(`${projectFolder}/Properties/AssemblyInfo.cs`),{
        projectName: projectFolder
      }
    );
    this.fs.copyTpl(
      this.templatePath('Ten10 Project.sln'),
      this.destinationPath(`${projectFolder}.sln`),{
        projectName: projectFolder
      }
    );
    
  }

  install() {
    this.spawnCommandSync('curl', ['https://dist.nuget.org/win-x86-commandline/latest/nuget.exe','--output', 'nuget.exe']),
    this.spawnCommand('nuget.exe', ['restore']);
  }
}